# Структура контекста AI PDLC: что за что отвечает

> Источник: доступный `skills-pipeline-v6.1-analytical-context` (manifest, stage access matrix, loading guide, pipeline) + отдельные актуальные frontend rules. В GitHub есть архив `Skills-Pipeline-v7.0.3.zip`, но содержимое его через доступное подключение не прочитано. Поэтому нельзя выдавать приведённую матрицу за побайтово подтверждённую схему v7.0.3.

## Как работает маршрутизация

1. `.gigacode/product-context.yaml` выбирает продуктовый контекст.
2. `product-system/context-manifest.yaml` задаёт списки документов и `loading`-профили этапов.
3. `07_business_context/stage_access_matrix.yaml` сопоставляет скилл, профиль и ожидаемые артефакты.
4. `source_registry.yaml`, `source_authority.md`, `current_product_sources.yaml` и `context_status.md` помогают определить источники, достоверность и состояние знаний.
5. `sources/analytical-specs/index.yaml` служит индексом дополнительных аналитических спецификаций. Их выбирают точечно, а не загружают целиком.

## Каталоги

| Каталог | Отвечает за | Использование |
|---|---|---|
| `01_product_foundation` | Миссия, философия, цель продукта | Intent / UX / SDD |
| `02_services` | Карта и описание сервисов, их сущностей | Intent / UX / SDD; по запросу prototype |
| `07_business_context` | Роли, словарь, бизнес-правила, ограничения, текущие возможности, решения, authority | Intent / UX / SDD; точечно другие этапы |
| `03_ux` | UX-принципы и поведенческие паттерны | UX / Prototype / UX Sync |
| `04_ui/visual` + `04_ui/patterns` | Визуальный язык, композиция, модалки, drawer, паттерны | Prototype; выборочно инженерная реализация |
| `04_ui/ui-kit` | Документы UI Kit, индексы компонентов | Инженерная реализация, но не production API сама по себе |
| `sources/analytical-specs` | Подтверждающие спецификации и ограничения | Точечный evidence для Intent, UX, SDD |
| `sources/frontend-rules` + целевые репозитории | Frontend-стандарты и фактический API/архитектура | План, код, тесты, ревью frontend |

## Куда обращаются скиллы

- `formulate-product-intent-and-brief`: foundation + business + services; выборочно аналитические спецификации. Не читает UX/UI по умолчанию.
- `design-ux-solution`: foundation + services + business + UX; точечные evidence о текущем продукте. Исключает технический UI Kit.
- `build-visual-html-prototype`: UX + visual + UI patterns; точечно релевантный service. **Не** превращает HTML в production UI Kit.
- `sync-ux-decisions`: артефакты задачи + review evidence + UX; обновляет согласованное UX-решение.
- `build-sdd-specification`: foundation + business + services + точечные domain specs + предыдущие task artifacts. Формализует наблюдаемое поведение, не frontend-архитектуру.
- `frontend-planner` и `frontend-standards-reviewer` — инженерная часть после SDD (по последующим правилам и работе над пайплайном): работают **target-first**, читают target repo, UI Kit API, frontend standards, SDD/UX/prototype. Этот этап не содержится в `stage_access_matrix.yaml` сборки v6.1 как формальная строка.

## Принцип источников

**Контекст продукта** — стабильные знания и ограничения; **артефакты задачи** — что решено именно в данном инкременте; **аналитические спецификации** — подтверждающие документы, по запросу; **target repo** — фактическая техническая истина при реализации.

Не надо загружать весь репозиторий в каждый этап. Не надо переносить DOM/CSS из прототипа в SDD. При frontend-реализации API UI Kit проверяется по установленному пакету и целевому проекту.

GitHub: https://github.com/hoseantonio85-art/skills-pipeline
